// Function to create a floating UI on the page
function createFloatingUI() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        chrome.scripting.executeScript(
            {
                target: { tabId: tab.id },
                func: () => {
                    // Check if the floating UI already exists
                    if (document.getElementById("aws-shopper-ui")) return;

                    // Create the floating UI container
                    const container = document.createElement("div");
                    container.id = "aws-shopper-ui";
                    container.style.cssText = `
                        position: fixed;
                        top: 10%;
                        right: 10px;
                        width: 250px;
                        background-color: #3e7356;
                        color: white;
                        font-family: 'Pixelated', Arial, sans-serif;
                        border: 2px solid #ffd700;
                        border-radius: 10px;
                        z-index: 10000;
                        padding: 10px;
                        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5);
                    `;

                    // Add title and instructions
                    const title = document.createElement("h3");
                    title.textContent = "AWS Shopper";
                    title.style.textAlign = "center";
                    title.style.marginBottom = "10px";
                    container.appendChild(title);

                    const instructions = document.createElement("p");
                    instructions.textContent = "Go to Amazon and click on an item.";
                    instructions.style.fontSize = "12px";
                    instructions.style.marginBottom = "10px";
                    container.appendChild(instructions);

                    // Add button
                    const button = document.createElement("button");
                    button.textContent = "Select Item";
                    button.style.cssText = `
                        display: block;
                        width: 100%;
                        padding: 10px;
                        background-color: #4caf50;
                        color: white;
                        border: none;
                        border-radius: 5px;
                        cursor: pointer;
                        font-size: 14px;
                    `;
                    container.appendChild(button);

                    // Handle the click on the "Select Item" button
                    button.addEventListener("click", () => {
                        let productName = document.querySelector('#productTitle')?.textContent.trim();
                        let priceWhole = document.querySelector('.a-price-whole')?.textContent.trim();
                        let priceDecimal = document.querySelector('.a-price-fraction')?.textContent.trim();

                        let price = priceWhole && priceDecimal ? `${priceWhole}${priceDecimal}` : null;

                        if (productName && price) {
                            const productData = `Product Name: ${productName}\nPrice: ${price}`;
                            navigator.clipboard.writeText(productData)
                                .then(() => {
                                    showNotification('success', "Product has been selected!");
                                })
                                .catch((err) => {
                                    console.error("Clipboard error:", err);
                                    showNotification('error', "Failed to copy product details.");
                                });
                        } else {
                            showNotification('error', "Failed to find product");
                        }
                    });

                    // Add close button
                    const closeButton = document.createElement("span");
                    closeButton.textContent = "�";
                    closeButton.style.cssText = `
                        position: absolute;
                        top: 5px;
                        right: 10px;
                        cursor: pointer;
                        font-size: 18px;
                    `;
                    container.appendChild(closeButton);

                    closeButton.addEventListener("click", () => {
                        container.remove();
                    });

                    document.body.appendChild(container);

                    // Function to show notifications
                    function showNotification(type, message) {
                        const notification = document.createElement("div");
                        notification.className = `notification ${type}`;
                        notification.textContent = message;

                        // Style the notification box
                        notification.style.cssText = `
                            background-color: ${type === 'success' ? '#4caf50' : '#f44336'};
                            color: white;
                            padding: 10px;
                            border-radius: 5px;
                            font-size: 14px;
                            margin-top: 10px;
                            text-align: center;
                            font-weight: bold;
                            position: relative;
                        `;

                        // Append the notification to the container
                        container.appendChild(notification);

                        // Remove notification after 3 seconds
                        setTimeout(() => {
                            notification.remove();
                        }, 3000);
                    }
                },
            },
            () => {
                if (chrome.runtime.lastError) {
                    console.error("Error injecting UI:", chrome.runtime.lastError.message);
                }
            }
        );
    });
}

// Trigger the creation of the floating UI
document.addEventListener("DOMContentLoaded", () => {
    createFloatingUI();
});
